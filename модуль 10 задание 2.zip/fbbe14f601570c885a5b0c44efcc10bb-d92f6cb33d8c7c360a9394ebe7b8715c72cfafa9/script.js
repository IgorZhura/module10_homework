const btn = document.querySelector('.btn');
btn.addEventListener('click', () => {
  let screenWidth = window.screen.width;
  let screenHeight = window.screen.height;
  alert(`Ширина экрана польователя: ${screenWidth} Высота экрана пользователя: ${screenHeight}`)
})