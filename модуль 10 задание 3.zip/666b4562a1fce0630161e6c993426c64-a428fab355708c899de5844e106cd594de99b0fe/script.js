const wsUrl = 'wss://echo-ws-service.herokuapp.com/';

const chat = document.getElementById("chat");
const input = document.querySelector('.input');
const btn = document.querySelector('.msg_btn');

let websocket;

function letStartChat(message) {
  let pre = document.createElement("p");
  pre.style.wordWrap = "break-word";
  pre.innerHTML = message;
  chat.appendChild(pre);
}

btn.addEventListener('click', () => {
  const message = 'Test message';
  letStartChat("SENT: " + message);
  websocket.send(message);
  });
  websocket = new WebSocket(wsUrl);
  websocket.onopen = function(evt) {
    letStartChat("CONNECTED");
  };
  websocket.onclose = function(evt) {
    letStartChat("DISCONNECTED");
  };
  websocket.onmessage = function(evt) {
    letStartChat(
      '<span style="color: blue;">RESPONSE: ' + evt.data+'</span>'
    );
  };
  websocket.onerror = function(evt) {
    letStartChat(
      '<span style="color: red;">ERROR:</span> ' + evt.data
    );
  };
  
const status = document.querySelector('#status');
const mapLink = document.querySelector('#map-link');
const nav_btn = document.querySelector('.nav_btn');

const error = () => {
  status.textContent = 'Невозможно получить ваше местоположение';
}

const success = (position) => {
  console.log('position', position);
  const latitude  = position.coords.latitude;
  const longitude = position.coords.longitude;

  status.textContent = `Широта: ${latitude} °, Долгота: ${longitude} °`;
  mapLink.href = `https://www.openstreetmap.org/#map=18/${latitude}/${longitude}`;
  mapLink.textContent = 'Ссылка на карту';
}

nav_btn.addEventListener('click', () => {
  mapLink.href = '';
  mapLink.textContent = '';
  
  if (!navigator.geolocation) {
    status.textContent = 'Geolocation не поддерживается вашим браузером';
  } else {
    status.textContent = 'Определение местоположения…';
    navigator.geolocation.getCurrentPosition(success, error);
  }
});